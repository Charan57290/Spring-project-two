package com.example.employeeapp.service;

import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.example.employeeapp.model.User;
import com.example.employeeapp.repository.UserRepository;

@Service
public class AuthService {

    private final UserRepository userRepository;

    public AuthService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public Map<String, Object> register(User user) {
        Map<String, Object> response = new HashMap<>();

        if (userRepository.findByUsername(user.getUsername()).isPresent()) {
            response.put("success", false);
            response.put("message", "Username already exists");
            return response;
        }

        userRepository.save(user);
        response.put("success", true);
        response.put("message", "Registration successful");
        return response;
    }

    public Map<String, Object> login(User user) {
        Map<String, Object> response = new HashMap<>();
        return userRepository.findByUsername(user.getUsername())
                .filter(u -> u.getPassword().equals(user.getPassword()))
                .map(u -> {
                    response.put("success", true);
                    response.put("message", "Login successful");
                    return response;
                })
                .orElseGet(() -> {
                    response.put("success", false);
                    response.put("message", "Invalid username or password");
                    return response;
                });
    }
}
