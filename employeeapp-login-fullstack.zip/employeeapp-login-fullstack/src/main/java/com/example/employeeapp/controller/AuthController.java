package com.example.employeeapp.controller;

import java.util.Map;
import org.springframework.web.bind.annotation.*;
import com.example.employeeapp.model.User;
import com.example.employeeapp.service.AuthService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public Map<String, Object> register(@Valid @RequestBody User user) {
        return authService.register(user);
    }

    @PostMapping("/login")
    public Map<String, Object> login(@Valid @RequestBody User user) {
        return authService.login(user);
    }
}
